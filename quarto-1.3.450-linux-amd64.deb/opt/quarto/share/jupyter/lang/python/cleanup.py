
# reset state
%reset
